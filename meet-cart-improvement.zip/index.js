const http = require("http");
const router = require("router")();
const bodyParser = require("body-parser");
const cart = require("./helpers/cart-operations");
const PORT = 9000;

router.use(bodyParser.json());

http.createServer((req, res) => {
    router(req, res, () => {
        res.writeHead(404, { "Content-Type": "application/json" });
        res.end(
            JSON.stringify({
                status: 400,
                message: "Please check api route.",
            })
        );
    });
}).listen(PORT, () => {
    console.log("\n-------------------------------------------");
    console.log(`Server is started and running on ${PORT}`);
});

/**
 * Add Items in cart.
 */
router.post("/cart/add/:id", (req, res, next) => {
    try {
        const { quantity } = req.body;
        const { id } = req.params;
        const { message, status, code } = cart.addItems(
            id,
            typeof quantity == "number" ? quantity : 1
        );
        if (!status) {
            res.writeHead(code, { "Content-Type": "application/json" });
            throw new Error(message);
        }
        res.writeHead(code, { "Content-Type": "application/json" });
        return res.end(
            JSON.stringify({
                status: code,
                message: message,
            })
        );
    } catch (error) {
        return next(new Error(error.message));
    }
});

/**
 * Empty the cart.
 */
router.delete("/cart/clear", (req, res, next) => {
    try {
        const { message, status, code } = cart.clearCart();
        if (!status) {
            res.writeHead(code, { "Content-Type": "application/json" });
            throw new Error(message);
        }
        res.writeHead(code, { "Content-Type": "application/json" });
        return res.end(
            JSON.stringify({
                status: code,
                message: message,
            })
        );
    } catch (error) {
        return next(new Error(error.message));
    }
});

/**
 * Put request to update a item.
 */
router.put("/cart/update/:id", (req, res, next) => {
    try {
        const { quantity } = req.body;
        const { id } = req.params;
        if (typeof quantity == "number") {
            const { message, status, code } = cart.updateItem(id, quantity);
            if (!status) {
                res.writeHead(code, { "Content-Type": "application/json" });
                throw new Error(message);
            }
            res.writeHead(code, { "Content-Type": "application/json" });
            return res.end(
                JSON.stringify({
                    status: code,
                    message: message,
                })
            );
        }
        res.writeHead(400, { "Content-Type": "application/json" });
        throw new Error("Please add positive integer.");
    } catch (error) {
        return next(new Error(error.message));
    }
});

/**
 * Get cart details.
 */
router.get("/cart/details", (req, res, next) => {
    try {
        res.writeHead(200, { "Content-Type": "application/json" });
        return res.end(
            JSON.stringify({
                status: 200,
                message: "Cart Details",
                data: cart.calculateSubTotal(),
            })
        );
    } catch (error) {
        return next(new Error(error.message));
    }
});

/**
 * Remove specific item from cart.
 */
router.delete("/cart/remove/:id", (req, res, next) => {
    try {
        const { id } = req.params;
        const { message, status, code } = cart.removeItem(id);
        if (!status) {
            res.writeHead(code, { "Content-Type": "application/json" });
            throw new Error(message);
        }
        res.writeHead(code, { "Content-Type": "application/json" });
        return res.end(
            JSON.stringify({
                status: code,
                message: message,
            })
        );
    } catch (error) {
        return next(new Error(error.message));
    }
});

/**
 * Get product list.
 */
router.get("/products", (req, res, next) => {
    try {
        res.writeHead(200, { "Content-Type": "application/json" });
        return res.end(
            JSON.stringify({
                status: 200,
                message: "Product Details",
                data: cart.productRecords(),
            })
        );
    } catch (error) {
        return next(new Error(error.message));
    }
});

/**
 * Error Handling
 */
router.use((error, req, res, next) => {
    // response.writeHead(400, { "Content-Type": "application/json" });
    return res.end(
        JSON.stringify({ status: res.statusCode, message: error.message })
    );
});
