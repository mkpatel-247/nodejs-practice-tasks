const fs = require("fs");
const path = require("path");
const file = path.join("tempory-data", "productData.json");
const shoppingCart = { items: [] };

/**
 * Read file and get product records.
 */
const productRecords = () => {
    return getDataFromFile(file);
};

/**
 * Add Items.
 */
function addItems(productId, quantities) {
    const productDetails = itemDetails(productRecords(), productId)?.details;
    if (productDetails) {
        const { details } = itemDetails(shoppingCart.items, productId);

        if (details) {
            return apiResponse("Product is already in cart.", false, 200);
        }
        if (quantities > 0) {
            shoppingCart.items.push({ quantity: quantities, id: productId });
            calculateSubTotal();
            return apiResponse("Product added in cart.", false, 201);
        }
        return apiResponse("Inappropriate quantity.", false, 400);
    } else {
        return apiResponse("Product not found.", false, 404);
    }
}

/**
 * Update product item quantity in cart.
 */
function updateItem(productId, quantities) {
    const productDetails = itemDetails(productRecords(), productId)?.details;

    if (productDetails) {
        const { index, details } = itemDetails(shoppingCart.items, productId);

        if (details) {
            let { quantity, ...rest } = details;
            if (quantities > 0) {
                quantity += quantities;
                shoppingCart.items[index] = { quantity, ...rest };
                calculateSubTotal();
                return apiResponse("Product update in cart.", true, 200);
            }
            return apiResponse("Inappropriate quantity.", false, 400);
        }
        return apiResponse("Please add product in cart.", false, 400);
    } else {
        return apiResponse("Product not found", false, 404);
    }
}

/**
 * Calculates cart.
 */
function calculateSubTotal() {
    const totalPrices = shoppingCart.items.map(
        (items) => items.quantity * findProduct(items.id).price
    );
    let subTotal = 0;
    totalPrices.forEach((price) => (subTotal += price));
    const taxes = subTotal * 0.1;
    const total = subTotal + taxes;
    const cartItems = [];
    shoppingCart.items.forEach((items) => {
        const quantity = items.quantity;
        cartItems.push({ ...findProduct(items.id), quantity });
    });
    summary(cartItems, subTotal, taxes, total);
    return { cartItems, subTotal, taxes, total };
}

/**
 * Find product details.
 */
const findProduct = (productId) => {
    return productRecords().find((ele) => {
        return ele.id == productId;
    });
};

/**
 * See cart details in console.
 */
function summary(cartItems, subTotal, taxes, total) {
    console.table(cartItems);
    console.log(`SubTotal : ${subTotal}`);
    console.log(`Tax : ${taxes}`);
    console.log(`Total : ${total}`);
    console.log("-----------------------------------\n");
}

/**
 * Clear cart.
 */
function clearCart() {
    shoppingCart.items = [];
    summary([], 0 , 0, 0);
    return apiResponse("Cart is empty.", true, 200);
}

/**
 * Remove a specific item from cart.
 */
function removeItem(productId) {
    const { index, details } = itemDetails(shoppingCart.items, productId);
    if (details) {
        shoppingCart.items.splice(index, 1);
        calculateSubTotal();
        return apiResponse("Product deleted from cart.", true, 200);
    }
    return apiResponse("Please first added product in cart.", false, 404);
}

/**
 * Returns the data from file.
 * @returns
 */
function getDataFromFile(filePath) {
    const bufferData = fs.readFileSync(filePath);
    const data = JSON.parse(bufferData.toString());
    return data;
}

/**
 * Helper function that return index from array and details.
 */
function itemDetails(array, id) {
    const index = array.findIndex((element) => element.id == id);
    const details = array.find((element) => element.id == id);
    return { index, details };
}

/**
 * Common json.
 * @param {*} message that we have to send in api response
 * @param {*} status status (boolean).
 * @param {*} code http status code.
 * @returns
 */
const apiResponse = (message, status, code) => {
    return { message, status, code };
};

module.exports = {
    addItems,
    clearCart,
    removeItem,
    calculateSubTotal,
    updateItem,
    productRecords,
};
