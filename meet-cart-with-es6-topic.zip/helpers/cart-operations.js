const fs = require("fs");
const path = require("path");
const shoppingCart = { items: [], subTotal: 0, taxes: 0, total: 0 };

/**
 * Add Items.
 */
function addItems(productId, quantities) {
  const file = path.join("tempory-data", "productData.json");
  const productList = getDataFromFile(file);
  const productDetails = itemDetails(productList, productId)?.details;
  if (productDetails) {
    const { index, details } = itemDetails(shoppingCart.items, productId);

    if (details) {
      return apiResponse("Product is already in cart.", false, 400);
    }
    if (quantities > 0) {
      shoppingCart.items.push({ quantity: quantities, ...productDetails });
      calculateSubTotal();
      return apiResponse("Product added in cart.", false, 201);
    }
    return apiResponse("Inappropriate quantity.", false, 400);
  } else {
    return apiResponse("Product not found.", false, 404);
  }
}

/**
 * Update product item quantity in cart.
 */
function updateItem(productId, quantities) {
  const file = path.join("tempory-data", "productData.json");
  const productList = getDataFromFile(file);
  const productDetails = itemDetails(productList, productId)?.details;

  if (productDetails) {
    const { index, details } = itemDetails(shoppingCart.items, productId);

    if (details) {
      let { quantity, ...rest } = details;
      if (quantities > 0) {
        quantity += quantities || 1;
        shoppingCart.items[index] = { quantity, ...rest };
        calculateSubTotal();
        return apiResponse("Product update in cart.", true, 200);
      }
      return apiResponse("Inappropriate quantity.", false, 400);
    }
    return apiResponse("Please add product in cart.", false, 400);
  } else {
    return apiResponse("Product not found", false, 404);
  }
}

/**
 * Calculates cart.
 */
function calculateSubTotal() {
  const totalPrices = shoppingCart.items.map(
    (items) => items.quantity * items.price
  );
  let subTotal = 0;
  totalPrices.forEach((price) => (subTotal += price));
  shoppingCart.subTotal = subTotal;
  shoppingCart.taxes = (subTotal * 10) / 100;
  shoppingCart.total = subTotal + shoppingCart.taxes;
  summary();
}

/**
 * See cart details in console.
 */
function summary() {
  console.table(shoppingCart.items);
  console.log(`SubTotal : ${shoppingCart.subTotal}`);
  console.log(`Tax : ${shoppingCart.taxes}`);
  console.log(`Total : ${shoppingCart.total}`);
  console.log("-----------------------------------\n");
}

/**
 * Clear cart.
 */
function clearCart() {
  if (!shoppingCart.items.length) {
    return apiResponse("Please first enter product in cart.", false, 404);
  }
  shoppingCart.items = [];
  shoppingCart.subTotal = 0;
  shoppingCart.total = 0;
  shoppingCart.taxes = 0;
  summary();
  return apiResponse("Cart is empty.", true, 200);
}

/**
 * Remove a specific item from cart.
 */
function removeItem(productId) {
  const { index, details } = itemDetails(shoppingCart.items, productId);
  if (details) {
    shoppingCart.items.splice(index, 1);
    calculateSubTotal();
    return apiResponse("Product deleted from cart.", true, 200);
  }
  return apiResponse("Please first added product in cart.", false, 404);
}

/**
 * Returns cart details.
 */
const cartDetails = () => {
  return shoppingCart;
};

/**
 * Returns the data from file.
 * @returns
 */
function getDataFromFile(filePath) {
  const bufferData = fs.readFileSync(filePath);
  const data = JSON.parse(bufferData.toString());
  return data;
}

/**
 * Helper function that return index from array and details.
 */
function itemDetails(array, id) {
  const index = array.findIndex((element) => element.id == id);
  const details = array.find((element) => element.id == id);
  return { index, details };
}

/**
 * Common json.
 * @param {*} message that we have to send in api response
 * @param {*} status status (boolean).
 * @param {*} code http status code.
 * @returns
 */
const apiResponse = (message, status, code) => {
  return { message, status, code };
};

module.exports = { addItems, clearCart, removeItem, cartDetails, updateItem };
