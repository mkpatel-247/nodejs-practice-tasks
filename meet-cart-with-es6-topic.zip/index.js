const http = require("http");
const router = require("router")();
const bodyParser = require("body-parser");
const cart = require("./helpers/cart-operations");
const PORT = 9000;

router.use(bodyParser.json());

http
  .createServer((req, res) => {
    router(req, res, () => {
      res.writeHead(404, { "Content-Type": "application/json" });
      res.end(
        JSON.stringify({
          status: 400,
          message: "Please check api route.",
        })
      );
    });
  })
  .listen(PORT, () => {
    console.log("\n-------------------------------------------");
    console.log(`Server is started and running on ${PORT}`);
  });

/**
 * Add Items in cart.
 */
router.post("/add-items/:id", (req, res, next) => {
  try {
    const { quantity } = req.body;
    const { id } = req.params;
    const { message, status, code } = cart.addItems(
      id,
      typeof quantity == "number" ? quantity : 1
    );
    if (!status) {
      res.writeHead(code, { "Content-Type": "application/json" });
      throw new Error(message);
    }
    res.writeHead(code, { "Content-Type": "application/json" });
    return res.end(
      JSON.stringify({
        status: code,
        message: message,
      })
    );
  } catch (error) {
    return next(new Error(error.message));
  }
});

/**
 * Empty the cart.
 */
router.delete("/clear-cart", (req, res, next) => {
  try {
    const { message, status, code } = cart.clearCart();
    if (!status) {
      res.writeHead(code, { "Content-Type": "application/json" });
      throw new Error(message);
    }
    res.writeHead(code, { "Content-Type": "application/json" });
    return res.end(
      JSON.stringify({
        status: code,
        message: message,
      })
    );
  } catch (error) {
    return next(new Error(error.message));
  }
});

/**
 * Put request to update a item.
 */
router.put("/update-items/:id", (req, res, next) => {
  try {
    const { quantity } = req.body;
    const { id } = req.params;
    const { message, status, code } = cart.updateItem(
      id,
      typeof quantity == "number" ? quantity : 1
    );
    if (!status) {
      res.writeHead(code, { "Content-Type": "application/json" });
      throw new Error(message);
    }
    res.writeHead(code, { "Content-Type": "application/json" });
    return res.end(
      JSON.stringify({
        status: code,
        message: message,
      })
    );
  } catch (error) {
    return next(new Error(error.message));
  }
});

/**
 * Get cart details.
 */
router.get("/cart-details", (req, res, next) => {
  try {
    res.writeHead(200, { "Content-Type": "application/json" });
    return res.end(
      JSON.stringify({
        status: 200,
        message: "Cart Details",
        data: cart.cartDetails(),
      })
    );
  } catch (error) {
    return next(new Error(error.message));
  }
});

/**
 * Remove specific item from cart.
 */
router.delete("/remove-item/:id", (req, res, next) => {
  try {
    const { id } = req.params;
    const { message, status, code } = cart.removeItem(id);
    if (!status) {
      res.writeHead(code, { "Content-Type": "application/json" });
      throw new Error(message);
    }
    res.writeHead(code, { "Content-Type": "application/json" });
    return res.end(
      JSON.stringify({
        status: code,
        message: message,
      })
    );
  } catch (error) {
    return next(new Error(error.message));
  }
});

/**
 * Error Handling
 */
router.use((error, req, res, next) => {
  // response.writeHead(400, { "Content-Type": "application/json" });
  return res.end(
    JSON.stringify({ status: res.statusCode, message: error.message })
  );
});
